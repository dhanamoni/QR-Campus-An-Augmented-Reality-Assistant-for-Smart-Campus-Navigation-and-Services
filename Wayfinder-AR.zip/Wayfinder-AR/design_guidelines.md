# AR Indoor Navigation App - Design Guidelines

## Architecture Decisions

### Authentication
**No authentication required.** This is a utility-focused wayfinding app for campus navigation with local-only functionality. However, include a **Settings screen** accessible from the destination selection screen with:
- App preferences (haptic feedback toggle, arrow opacity slider)
- Tutorial/Help section
- About section with campus map overview

### Navigation Structure
**Stack-Only Navigation** - Linear flow optimized for quick wayfinding:
1. QR Scanner Screen (Entry point)
2. Destination Selection Screen
3. AR Navigation Screen
4. Arrival Confirmation Screen
5. Settings Screen (modal from Destination Selection)

The app follows a clear sequential path: Scan entrance → Choose destination → Navigate → Arrive

## Screen Specifications

### 1. QR Scanner Screen (Entry Point)
**Purpose:** Scan QR code at campus entrance to determine starting point

**Layout:**
- Full-screen camera viewfinder
- Transparent header with app title "Campus Navigator" centered
- Semi-transparent overlay with scanning frame in center
- Bottom instruction panel (floating, rounded corners)

**Components:**
- Live camera feed (full screen)
- Animated scanning frame (240x240pt square with corner brackets)
- Instruction text: "Scan entrance QR code to begin"
- Manual entrance selection button (bottom, small text link)
- Flashlight toggle (top-right corner icon)

**Safe Areas:**
- Top: insets.top + Spacing.xl
- Bottom: insets.bottom + Spacing.xl
- Instruction panel floats 80pt from bottom edge

### 2. Destination Selection Screen
**Purpose:** Choose navigation destination after entrance identified

**Layout:**
- Custom header with entrance identifier (e.g., "Starting from Entrance 1")
- Settings icon (top-right)
- Scrollable grid/list of destination cards
- Large, tappable destination buttons

**Components:**
- Header with back button (left) and settings icon (right)
- Subheader showing current entrance location
- 7 destination cards in 2-column grid layout
  - Tech Society
  - Old ICT Building  
  - New ICT Building
  - Exam Hall
  - IoT Lab
  - Administration Office
  - Robotics Lab
- Each card shows:
  - Location icon (unique Feather icon per destination)
  - Location name (semibold, 16pt)
  - Estimated walking time (light, 12pt)

**Safe Areas:**
- Top: Spacing.xl (non-transparent header)
- Bottom: insets.bottom + Spacing.xl
- Content padding: Spacing.lg horizontal

### 3. AR Navigation Screen
**Purpose:** Display real-time AR guidance with floating arrows on camera feed

**Layout:**
- Full-screen AR camera view
- Transparent top bar with minimal UI
- Floating AR directional arrows rendered in 3D space
- Bottom instruction card (semi-transparent)

**Components:**
- Live AR camera feed (full screen)
- 3D floating arrow overlays pointing direction to move
- Top bar (transparent):
  - Back/Exit button (top-left, X icon)
  - Destination name (center)
  - Current step indicator (e.g., "2/5")
- Bottom instruction card (rounded, glassmorphic):
  - Current instruction text (e.g., "Walk 10 feet straight")
  - Distance remaining to destination
  - Next turn preview (small text)
- Recenter button (if user loses tracking)

**Safe Areas:**
- Top bar: insets.top + Spacing.md
- Bottom card: insets.bottom + 90pt from bottom
- Floats above bottom edge

**AR Arrow Specifications:**
- 3D arrows rendered at eye level in AR space
- Bright, high-contrast color (primary color with glow)
- Animate smoothly when direction changes
- Scale based on distance (larger when closer to turn)
- Pulse animation for emphasis

### 4. Arrival Confirmation Screen
**Purpose:** Confirm successful arrival at destination

**Layout:**
- Centered success message
- Confetti or checkmark animation
- Action buttons at bottom

**Components:**
- Success icon (large checkmark, 80pt)
- "You've arrived at [Destination]" heading
- "Navigate somewhere else" primary button
- "Return to scanner" secondary button link

**Safe Areas:**
- Centered vertically with 40pt spacing between elements
- Bottom buttons: insets.bottom + Spacing.xl

### 5. Settings Screen (Modal)
**Purpose:** App preferences and help

**Layout:**
- Standard navigation header with "Settings" title
- Scrollable form with grouped sections

**Components:**
- Close button (top-left, X or Done)
- Grouped settings sections:
  - **Navigation Preferences**
    - Haptic feedback toggle
    - Arrow opacity slider
    - Voice guidance toggle (future feature placeholder)
  - **Help & Support**
    - Tutorial button
    - View campus map button
  - **About**
    - App version
    - Credits

**Safe Areas:**
- Top: Spacing.xl (non-transparent header)
- Bottom: insets.bottom + Spacing.xl

## Design System

### Color Palette
**Primary:** Navigation blue (#2196F3) - for AR arrows, active states
**Secondary:** Campus teal (#00BCD4) - for accents, icons
**Background:** Pure white (#FFFFFF) for cards, overlays
**Surface:** Light gray (#F5F5F5) for screen backgrounds
**Text Primary:** Dark gray (#212121)
**Text Secondary:** Medium gray (#757575)
**Success:** Green (#4CAF50) for arrival confirmation
**Warning:** Amber (#FFC107) for GPS/tracking issues
**Error:** Red (#F44336) for scanner errors

### Typography
- **Headings (H1):** 28pt, Semibold
- **Headings (H2):** 20pt, Semibold  
- **Body:** 16pt, Regular
- **Caption:** 12pt, Regular
- **AR Instructions:** 18pt, Medium (high readability)

### Spacing Scale
- **xs:** 4pt
- **sm:** 8pt
- **md:** 16pt
- **lg:** 24pt
- **xl:** 32pt

### Visual Design Principles

**Touchable Feedback:**
- Destination cards: Scale down to 0.96 + subtle shadow on press
- Buttons: Reduce opacity to 0.7 on press
- AR arrows: No direct touch interaction (spatial UI)

**Glassmorphic Overlays:**
- Bottom instruction card on AR screen uses semi-transparent white background (opacity 0.85)
- Light blur effect (10pt radius)
- Subtle 1pt border with white/10 opacity
- Drop shadow: offset (0, 4), opacity 0.15, radius 12

**Floating Action Elements:**
For the "Recenter" button on AR screen:
- shadowOffset: {width: 0, height: 2}
- shadowOpacity: 0.10
- shadowRadius: 2
- Circular button, 56pt diameter

**Icons:**
- Use Feather icons from @expo/vector-icons exclusively
- Navigation icons: 24pt
- Location cards: 32pt icons
- AR UI: 20pt icons

**AR Arrow Design:**
- Custom 3D arrow model or SVG-based directional indicator
- Bright gradient fill (primary color to lighter tint)
- Outer glow effect for visibility
- Animated pulsing at 1-second intervals
- Rotate smoothly when direction changes (300ms easing)

### Critical Assets
1. **Entrance QR Codes** (2 assets)
   - Unique QR codes for Entrance 1 and Entrance 2
   - Include visual label below QR (e.g., "ENTRANCE 1")
   
2. **Location Icons** (7 unique icons from Feather set)
   - Tech Society: `cpu`
   - Old ICT: `monitor`
   - New ICT: `server`
   - Exam Hall: `edit-3`
   - IoT Lab: `activity`
   - Administration: `briefcase`
   - Robotics Lab: `tool`

3. **AR Arrow 3D Model or SVG**
   - Single directional arrow asset in primary color
   - Optimized for real-time rendering

### Accessibility Requirements
- High contrast between AR arrows and typical indoor environments
- Text instructions always accompany visual AR arrows
- Large touch targets (minimum 44pt) for all interactive elements
- VoiceOver labels for all navigation elements
- Haptic feedback on successful QR scan and arrival

### Camera Permissions
- Request camera permission on app launch with clear explanation
- "Campus Navigator needs camera access to scan QR codes and display AR navigation"
- Graceful fallback: Manual entrance selection if camera denied