# Campus Navigator - AR Indoor Navigation App

## Overview
Campus Navigator is an AR-powered indoor wayfinding mobile application built with Expo and React Native. The app helps users navigate within a campus by scanning QR codes at entrances and providing step-by-step AR directions with floating arrows to reach various destinations.

## Current State
- **Status**: MVP Complete
- **Last Updated**: December 2024
- **Platform**: Expo (iOS, Android, Web)

## Features
1. **QR Code Scanner**: Scan entrance QR codes (Entrance1 or Entrance2) to determine starting point
2. **Destination Selection**: Choose from 7 campus locations with estimated walking times
3. **AR Navigation**: Live camera view with floating directional arrows and step-by-step instructions
4. **Arrival Confirmation**: Celebratory screen with confetti animation upon reaching destination
5. **Settings**: Toggle haptic feedback, view tutorial (placeholder), and app info

## Project Architecture

### Directory Structure
```
client/
├── components/        # Reusable UI components
│   ├── Button.tsx
│   ├── Card.tsx
│   ├── ErrorBoundary.tsx
│   ├── ErrorFallback.tsx
│   ├── HeaderTitle.tsx
│   ├── KeyboardAwareScrollViewCompat.tsx
│   ├── Spacer.tsx
│   ├── ThemedText.tsx
│   └── ThemedView.tsx
├── constants/
│   ├── routes.ts      # Navigation routes and destinations data
│   └── theme.ts       # Design tokens (colors, spacing, typography)
├── hooks/
│   ├── useColorScheme.ts
│   ├── useScreenOptions.ts
│   └── useTheme.ts
├── navigation/
│   └── RootStackNavigator.tsx  # Stack-based navigation
├── screens/
│   ├── QRScannerScreen.tsx     # Entry point with QR scanner
│   ├── DestinationScreen.tsx   # Destination selection grid
│   ├── ARNavigationScreen.tsx  # AR camera with floating arrows
│   ├── ArrivalScreen.tsx       # Arrival confirmation
│   └── SettingsScreen.tsx      # App settings modal
├── App.tsx
└── index.js

server/
├── index.ts           # Express server entry point
├── routes.ts          # API routes
└── storage.ts         # Storage utilities

assets/
└── images/            # App icons and splash screen
```

### Navigation Flow
1. QRScannerScreen (Entry) → DestinationScreen → ARNavigationScreen → ArrivalScreen
2. Settings accessible as modal from DestinationScreen

### Key Technologies
- **Frontend**: React Native with Expo SDK 54
- **Navigation**: React Navigation 7 (Native Stack)
- **Camera/QR**: expo-camera
- **Animations**: react-native-reanimated
- **State Management**: React hooks, @tanstack/react-query
- **Backend**: Express.js with TypeScript

## Destinations
- Tech Society
- Old ICT Building
- New ICT Building
- Exam Hall
- IoT Lab
- Administration Office
- Robotics Lab

## Routes Configuration
Routes are defined in `client/constants/routes.ts` with step-by-step directions from each entrance to each destination. Each route contains:
- Entrance identifier
- Destination ID
- Array of navigation steps (instruction, distance, direction)
- Total distance

## Design System
- **Primary Color**: Navigation Blue (#2196F3)
- **Secondary Color**: Campus Teal (#00BCD4)
- **Success Color**: Green (#4CAF50)
- **Typography**: System fonts with custom heading/body styles
- **Spacing Scale**: xs (4), sm (8), md (16), lg (24), xl (32)

## Development

### Running the App
```bash
npm run all:dev
```
This starts both the Expo dev server (port 8081) and Express backend (port 5000).

### Testing on Device
Scan the QR code shown in the terminal with Expo Go app on iOS or Android.

### Web Preview
The web version is available but camera features are limited. AR navigation shows a fallback UI on web.

## User Preferences
- None specified yet

## Recent Changes
- Initial MVP implementation with QR scanner, destination selection, AR navigation, and arrival screens
- Implemented animated floating arrows for AR navigation
- Added confetti celebration animation on arrival
- Created settings screen with haptic feedback toggle
