export const ENTRANCES = {
  ENTRANCE1: "Entrance1",
  ENTRANCE2: "Entrance2",
} as const;

export type EntranceType = (typeof ENTRANCES)[keyof typeof ENTRANCES];

export interface Destination {
  id: string;
  name: string;
  icon: string;
  estimatedTime: string;
}

export const DESTINATIONS: Destination[] = [
  { id: "tech-society", name: "Tech Society", icon: "cpu", estimatedTime: "2 min" },
  { id: "old-ict", name: "Old ICT Building", icon: "monitor", estimatedTime: "3 min" },
  { id: "new-ict", name: "New ICT Building", icon: "server", estimatedTime: "4 min" },
  { id: "exam-hall", name: "Exam Hall", icon: "edit-3", estimatedTime: "5 min" },
  { id: "iot-lab", name: "IoT Lab", icon: "activity", estimatedTime: "3 min" },
  { id: "admin-office", name: "Administration Office", icon: "briefcase", estimatedTime: "4 min" },
  { id: "robotics-lab", name: "Robotics Lab", icon: "tool", estimatedTime: "5 min" },
];

export interface NavigationStep {
  instruction: string;
  distance: string;
  direction: "straight" | "left" | "right" | "arrived";
}

export interface Route {
  entrance: EntranceType;
  destination: string;
  steps: NavigationStep[];
  totalDistance: string;
}

export const ROUTES: Route[] = [
  {
    entrance: "Entrance1",
    destination: "tech-society",
    steps: [
      { instruction: "Walk straight ahead", distance: "10 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "2 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "12 feet",
  },
  {
    entrance: "Entrance1",
    destination: "old-ict",
    steps: [
      { instruction: "Walk straight ahead", distance: "15 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "8 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "23 feet",
  },
  {
    entrance: "Entrance1",
    destination: "new-ict",
    steps: [
      { instruction: "Walk straight ahead", distance: "20 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "15 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Walk to the building", distance: "5 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "40 feet",
  },
  {
    entrance: "Entrance1",
    destination: "exam-hall",
    steps: [
      { instruction: "Walk straight ahead", distance: "25 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "20 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "45 feet",
  },
  {
    entrance: "Entrance1",
    destination: "iot-lab",
    steps: [
      { instruction: "Walk straight ahead", distance: "10 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "12 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "22 feet",
  },
  {
    entrance: "Entrance1",
    destination: "admin-office",
    steps: [
      { instruction: "Walk straight ahead", distance: "30 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "10 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "40 feet",
  },
  {
    entrance: "Entrance1",
    destination: "robotics-lab",
    steps: [
      { instruction: "Walk straight ahead", distance: "20 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "25 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Walk to the lab", distance: "5 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "50 feet",
  },
  {
    entrance: "Entrance2",
    destination: "tech-society",
    steps: [
      { instruction: "Walk straight ahead", distance: "5 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "15 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Walk to destination", distance: "3 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "23 feet",
  },
  {
    entrance: "Entrance2",
    destination: "old-ict",
    steps: [
      { instruction: "Walk straight ahead", distance: "8 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "10 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "18 feet",
  },
  {
    entrance: "Entrance2",
    destination: "new-ict",
    steps: [
      { instruction: "Walk straight ahead", distance: "12 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "8 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "20 feet",
  },
  {
    entrance: "Entrance2",
    destination: "exam-hall",
    steps: [
      { instruction: "Walk straight ahead", distance: "15 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "25 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Walk to the hall", distance: "5 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "45 feet",
  },
  {
    entrance: "Entrance2",
    destination: "iot-lab",
    steps: [
      { instruction: "Walk straight ahead", distance: "20 feet", direction: "straight" },
      { instruction: "Turn left", distance: "Turn", direction: "left" },
      { instruction: "Continue walking", distance: "5 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "25 feet",
  },
  {
    entrance: "Entrance2",
    destination: "admin-office",
    steps: [
      { instruction: "Walk straight ahead", distance: "10 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "18 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Walk to the office", distance: "7 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "35 feet",
  },
  {
    entrance: "Entrance2",
    destination: "robotics-lab",
    steps: [
      { instruction: "Walk straight ahead", distance: "25 feet", direction: "straight" },
      { instruction: "Turn right", distance: "Turn", direction: "right" },
      { instruction: "Continue walking", distance: "15 feet", direction: "straight" },
      { instruction: "You have arrived", distance: "0 feet", direction: "arrived" },
    ],
    totalDistance: "40 feet",
  },
];

export function getRoute(entrance: EntranceType, destinationId: string): Route | undefined {
  return ROUTES.find(
    (route) => route.entrance === entrance && route.destination === destinationId
  );
}

export function getDestinationById(id: string): Destination | undefined {
  return DESTINATIONS.find((dest) => dest.id === id);
}
