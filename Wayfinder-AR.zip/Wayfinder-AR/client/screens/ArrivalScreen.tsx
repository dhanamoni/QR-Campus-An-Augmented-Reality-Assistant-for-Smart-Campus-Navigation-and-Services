import React, { useEffect } from "react";
import { View, StyleSheet, Pressable, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withDelay,
  withTiming,
  Easing,
} from "react-native-reanimated";
import { NativeStackScreenProps } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "Arrival">;

function ConfettiPiece({ delay, startX, color }: { delay: number; startX: number; color: string }) {
  const translateY = useSharedValue(-50);
  const translateX = useSharedValue(startX);
  const rotate = useSharedValue(0);
  const opacity = useSharedValue(1);

  useEffect(() => {
    translateY.value = withDelay(
      delay,
      withTiming(400, { duration: 2000, easing: Easing.out(Easing.quad) })
    );
    translateX.value = withDelay(
      delay,
      withTiming(startX + (Math.random() - 0.5) * 100, { duration: 2000 })
    );
    rotate.value = withDelay(
      delay,
      withTiming(360 * (Math.random() > 0.5 ? 1 : -1), { duration: 2000 })
    );
    opacity.value = withDelay(
      delay + 1500,
      withTiming(0, { duration: 500 })
    );
  }, []);

  const style = useAnimatedStyle(() => ({
    transform: [
      { translateY: translateY.value },
      { translateX: translateX.value },
      { rotate: `${rotate.value}deg` },
    ],
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      style={[
        styles.confettiPiece,
        { backgroundColor: color },
        style,
      ]}
    />
  );
}

export default function ArrivalScreen({ navigation, route }: Props) {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { destination } = route.params;

  const checkScale = useSharedValue(0);
  const checkOpacity = useSharedValue(0);
  const textOpacity = useSharedValue(0);
  const buttonsOpacity = useSharedValue(0);

  useEffect(() => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    checkScale.value = withSequence(
      withTiming(1.2, { duration: 300 }),
      withSpring(1, { damping: 10 })
    );
    checkOpacity.value = withTiming(1, { duration: 300 });
    textOpacity.value = withDelay(200, withTiming(1, { duration: 400 }));
    buttonsOpacity.value = withDelay(400, withTiming(1, { duration: 400 }));
  }, []);

  const checkStyle = useAnimatedStyle(() => ({
    transform: [{ scale: checkScale.value }],
    opacity: checkOpacity.value,
  }));

  const textStyle = useAnimatedStyle(() => ({
    opacity: textOpacity.value,
  }));

  const buttonsStyle = useAnimatedStyle(() => ({
    opacity: buttonsOpacity.value,
  }));

  const handleNavigateAgain = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    navigation.popToTop();
    navigation.navigate("Destination", { entrance: "Entrance1" });
  };

  const handleReturnToScanner = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    navigation.popToTop();
  };

  const confettiColors = [
    Colors.light.primary,
    Colors.light.secondary,
    Colors.light.success,
    Colors.light.warning,
    "#FF6B6B",
    "#9B59B6",
  ];

  return (
    <ThemedView style={styles.container}>
      <View style={styles.confettiContainer}>
        {Array.from({ length: 20 }).map((_, i) => (
          <ConfettiPiece
            key={i}
            delay={i * 50}
            startX={(i % 5) * 80 - 160}
            color={confettiColors[i % confettiColors.length]}
          />
        ))}
      </View>

      <View
        style={[
          styles.content,
          {
            paddingTop: insets.top + Spacing.xl,
            paddingBottom: insets.bottom + Spacing.xl,
          },
        ]}
      >
        <View style={styles.successSection}>
          <Animated.View
            style={[
              styles.checkContainer,
              { backgroundColor: Colors.light.success + "20" },
              checkStyle,
            ]}
          >
            <Feather name="check" size={48} color={Colors.light.success} />
          </Animated.View>

          <Animated.View style={textStyle}>
            <ThemedText type="h1" style={styles.title}>
              You've arrived!
            </ThemedText>
            <ThemedText
              type="body"
              style={[styles.subtitle, { color: theme.textSecondary }]}
            >
              Welcome to {destination.name}
            </ThemedText>
          </Animated.View>
        </View>

        <Animated.View style={[styles.buttonsSection, buttonsStyle]}>
          <Pressable
            onPress={handleNavigateAgain}
            style={({ pressed }) => [
              styles.primaryButton,
              { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Feather name="navigation" size={20} color="#FFFFFF" />
            <ThemedText type="body" style={{ color: "#FFFFFF", fontWeight: "600" }}>
              Navigate somewhere else
            </ThemedText>
          </Pressable>

          <Pressable
            onPress={handleReturnToScanner}
            style={({ pressed }) => [
              styles.secondaryButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <ThemedText type="body" style={{ color: theme.primary }}>
              Return to scanner
            </ThemedText>
          </Pressable>
        </Animated.View>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  confettiContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 200,
    alignItems: "center",
    overflow: "hidden",
  },
  confettiPiece: {
    position: "absolute",
    width: 10,
    height: 10,
    borderRadius: 2,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  successSection: {
    alignItems: "center",
    marginBottom: Spacing["3xl"],
  },
  checkContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  title: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  subtitle: {
    textAlign: "center",
  },
  buttonsSection: {
    gap: Spacing.md,
  },
  primaryButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
    gap: Spacing.sm,
  },
  secondaryButton: {
    alignItems: "center",
    paddingVertical: Spacing.md,
  },
});
