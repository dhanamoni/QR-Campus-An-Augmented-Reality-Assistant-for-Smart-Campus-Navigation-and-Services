import React, { useState } from "react";
import { View, StyleSheet, ScrollView, Switch, Pressable, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "Settings">;

interface SettingRowProps {
  icon: string;
  title: string;
  subtitle?: string;
  onPress?: () => void;
  rightElement?: React.ReactNode;
}

function SettingRow({ icon, title, subtitle, onPress, rightElement }: SettingRowProps) {
  const { theme } = useTheme();

  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [
        styles.settingRow,
        { backgroundColor: theme.backgroundDefault, opacity: pressed && onPress ? 0.8 : 1 },
      ]}
    >
      <View style={[styles.settingIcon, { backgroundColor: Colors.light.primary + "15" }]}>
        <Feather name={icon as any} size={20} color={theme.primary} />
      </View>
      <View style={styles.settingContent}>
        <ThemedText type="body" style={{ fontWeight: "500" }}>
          {title}
        </ThemedText>
        {subtitle ? (
          <ThemedText type="small" style={{ color: theme.textSecondary }}>
            {subtitle}
          </ThemedText>
        ) : null}
      </View>
      {rightElement ? (
        rightElement
      ) : onPress ? (
        <Feather name="chevron-right" size={20} color={theme.textSecondary} />
      ) : null}
    </Pressable>
  );
}

export default function SettingsScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();

  const [hapticEnabled, setHapticEnabled] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(false);

  const handleHapticToggle = (value: boolean) => {
    setHapticEnabled(value);
    if (Platform.OS !== "web" && value) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleVoiceToggle = (value: boolean) => {
    setVoiceEnabled(value);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <ThemedText
            type="small"
            style={[styles.sectionTitle, { color: theme.textSecondary }]}
          >
            NAVIGATION PREFERENCES
          </ThemedText>
          <View style={styles.sectionContent}>
            <SettingRow
              icon="smartphone"
              title="Haptic Feedback"
              subtitle="Vibrate on navigation events"
              rightElement={
                <Switch
                  value={hapticEnabled}
                  onValueChange={handleHapticToggle}
                  trackColor={{ false: theme.backgroundTertiary, true: theme.primary + "80" }}
                  thumbColor={hapticEnabled ? theme.primary : theme.backgroundSecondary}
                />
              }
            />
            <View style={[styles.divider, { backgroundColor: theme.backgroundSecondary }]} />
            <SettingRow
              icon="volume-2"
              title="Voice Guidance"
              subtitle="Coming soon"
              rightElement={
                <Switch
                  value={voiceEnabled}
                  onValueChange={handleVoiceToggle}
                  trackColor={{ false: theme.backgroundTertiary, true: theme.primary + "80" }}
                  thumbColor={voiceEnabled ? theme.primary : theme.backgroundSecondary}
                  disabled
                />
              }
            />
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText
            type="small"
            style={[styles.sectionTitle, { color: theme.textSecondary }]}
          >
            HELP & SUPPORT
          </ThemedText>
          <View style={styles.sectionContent}>
            <SettingRow
              icon="book-open"
              title="Tutorial"
              subtitle="Learn how to use the app"
              onPress={() => {}}
            />
            <View style={[styles.divider, { backgroundColor: theme.backgroundSecondary }]} />
            <SettingRow
              icon="map"
              title="View Campus Map"
              subtitle="See all locations"
              onPress={() => {}}
            />
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText
            type="small"
            style={[styles.sectionTitle, { color: theme.textSecondary }]}
          >
            ABOUT
          </ThemedText>
          <View style={styles.sectionContent}>
            <SettingRow
              icon="info"
              title="App Version"
              rightElement={
                <ThemedText type="small" style={{ color: theme.textSecondary }}>
                  1.0.0
                </ThemedText>
              }
            />
            <View style={[styles.divider, { backgroundColor: theme.backgroundSecondary }]} />
            <SettingRow
              icon="heart"
              title="Credits"
              subtitle="Built with Expo"
              onPress={() => {}}
            />
          </View>
        </View>

        <View style={styles.footer}>
          <ThemedText type="small" style={{ color: theme.textSecondary, textAlign: "center" }}>
            Campus Navigator helps you find your way around campus with AR-powered navigation.
          </ThemedText>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: Spacing.lg,
    paddingHorizontal: Spacing.lg,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.sm,
    marginLeft: Spacing.xs,
    fontWeight: "500",
    letterSpacing: 0.5,
  },
  sectionContent: {
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    gap: Spacing.md,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
  },
  settingContent: {
    flex: 1,
  },
  divider: {
    height: 1,
    marginLeft: 36 + Spacing.md * 2,
  },
  footer: {
    marginTop: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
});
