import React, { useState, useEffect } from "react";
import { View, StyleSheet, Pressable, Platform, Dimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CameraView, useCameraPermissions } from "expo-camera";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  withSpring,
  Easing,
  interpolate,
  runOnJS,
} from "react-native-reanimated";
import { NativeStackScreenProps } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "ARNavigation">;

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

interface DirectionalArrowProps {
  direction: "straight" | "left" | "right" | "arrived";
}

function DirectionalArrow({ direction }: DirectionalArrowProps) {
  const scale = useSharedValue(1);
  const translateY = useSharedValue(0);
  const glow = useSharedValue(0.5);

  const getRotationDegrees = (dir: string): number => {
    switch (dir) {
      case "left":
        return -90;
      case "right":
        return 90;
      case "arrived":
        return 0;
      default:
        return 0;
    }
  };

  const rotationDegrees = getRotationDegrees(direction);

  useEffect(() => {
    scale.value = withRepeat(
      withSequence(
        withTiming(1.1, { duration: 800 }),
        withTiming(1, { duration: 800 })
      ),
      -1,
      true
    );

    translateY.value = withRepeat(
      withSequence(
        withTiming(-10, { duration: 1000 }),
        withTiming(0, { duration: 1000 })
      ),
      -1,
      true
    );

    glow.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1000 }),
        withTiming(0.5, { duration: 1000 })
      ),
      -1,
      true
    );
  }, []);

  const arrowStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
      { translateY: translateY.value },
      { rotate: `${rotationDegrees}deg` },
    ],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: interpolate(glow.value, [0.5, 1], [0.3, 0.6]),
    transform: [{ scale: interpolate(glow.value, [0.5, 1], [1, 1.3]) }],
  }));

  if (direction === "arrived") {
    return (
      <View style={styles.arrowContainer}>
        <Animated.View style={[styles.glowCircle, glowStyle]} />
        <Animated.View style={[styles.arrowBox, arrowStyle]}>
          <Feather name="check-circle" size={80} color={Colors.light.success} />
        </Animated.View>
      </View>
    );
  }

  return (
    <View style={styles.arrowContainer}>
      <Animated.View style={[styles.glowCircle, glowStyle]} />
      <Animated.View style={[styles.arrowBox, arrowStyle]}>
        <View style={styles.arrowShape}>
          <View style={[styles.arrowHead, { borderBottomColor: Colors.light.primary }]} />
          <View style={[styles.arrowStem, { backgroundColor: Colors.light.primary }]} />
        </View>
      </Animated.View>
    </View>
  );
}

export default function ARNavigationScreen({ navigation, route }: Props) {
  const insets = useSafeAreaInsets();
  const { theme, isDark } = useTheme();
  const [permission] = useCameraPermissions();
  const { destination, route: navRoute } = route.params;

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const currentStep = navRoute.steps[currentStepIndex];
  const totalSteps = navRoute.steps.length;

  const progressWidth = useSharedValue(0);

  useEffect(() => {
    const progress = ((currentStepIndex + 1) / totalSteps) * 100;
    progressWidth.value = withSpring(progress, { damping: 15 });
  }, [currentStepIndex, totalSteps]);

  const progressStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value}%`,
  }));

  const handleNextStep = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }

    if (currentStepIndex < totalSteps - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    } else {
      navigation.navigate("Arrival", { destination });
    }
  };

  const handlePreviousStep = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const handleClose = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    navigation.goBack();
  };

  const nextStepPreview =
    currentStepIndex < totalSteps - 2
      ? `Next: ${navRoute.steps[currentStepIndex + 1].instruction}`
      : currentStepIndex === totalSteps - 2
        ? "Almost there!"
        : "";

  const renderCameraOrFallback = () => {
    if (Platform.OS === "web" || !permission?.granted) {
      return (
        <View style={[styles.fallbackCamera, { backgroundColor: theme.backgroundSecondary }]}>
          <DirectionalArrow direction={currentStep.direction} />
          <ThemedText
            type="small"
            style={[styles.fallbackText, { color: theme.textSecondary }]}
          >
            {Platform.OS === "web"
              ? "AR camera available in Expo Go"
              : "Camera permission required for AR view"}
          </ThemedText>
        </View>
      );
    }

    return (
      <>
        <CameraView style={StyleSheet.absoluteFill} facing="back" />
        <View style={styles.arOverlay}>
          <DirectionalArrow direction={currentStep.direction} />
        </View>
      </>
    );
  };

  return (
    <View style={styles.container}>
      {renderCameraOrFallback()}

      <View style={[styles.topBar, { paddingTop: insets.top + Spacing.md }]}>
        <Pressable
          onPress={handleClose}
          style={({ pressed }) => [styles.closeButton, { opacity: pressed ? 0.7 : 1 }]}
        >
          <BlurView intensity={80} tint={isDark ? "dark" : "light"} style={styles.blurButton}>
            <Feather name="x" size={24} color={theme.text} />
          </BlurView>
        </Pressable>

        <BlurView intensity={80} tint={isDark ? "dark" : "light"} style={styles.destinationBadge}>
          <ThemedText type="h4" numberOfLines={1}>
            {destination.name}
          </ThemedText>
        </BlurView>

        <BlurView intensity={80} tint={isDark ? "dark" : "light"} style={styles.stepIndicator}>
          <ThemedText type="small" style={{ fontWeight: "600" }}>
            {currentStepIndex + 1}/{totalSteps}
          </ThemedText>
        </BlurView>
      </View>

      <View style={[styles.bottomSection, { paddingBottom: insets.bottom + Spacing.lg }]}>
        <BlurView intensity={90} tint={isDark ? "dark" : "light"} style={styles.instructionCard}>
          <View style={styles.progressBarContainer}>
            <View style={[styles.progressBarBg, { backgroundColor: theme.backgroundTertiary }]}>
              <Animated.View
                style={[
                  styles.progressBarFill,
                  { backgroundColor: theme.primary },
                  progressStyle,
                ]}
              />
            </View>
          </View>

          <View style={styles.instructionContent}>
            <View style={styles.instructionHeader}>
              <View
                style={[
                  styles.directionIcon,
                  { backgroundColor: Colors.light.primary + "20" },
                ]}
              >
                <Feather
                  name={
                    currentStep.direction === "left"
                      ? "corner-up-left"
                      : currentStep.direction === "right"
                        ? "corner-up-right"
                        : currentStep.direction === "arrived"
                          ? "check-circle"
                          : "arrow-up"
                  }
                  size={24}
                  color={
                    currentStep.direction === "arrived"
                      ? Colors.light.success
                      : theme.primary
                  }
                />
              </View>
              <View style={styles.instructionTextContainer}>
                <ThemedText type="h3">{currentStep.instruction}</ThemedText>
                <ThemedText
                  type="body"
                  style={[styles.distanceText, { color: theme.textSecondary }]}
                >
                  {currentStep.distance}
                </ThemedText>
              </View>
            </View>

            {nextStepPreview ? (
              <ThemedText
                type="small"
                style={[styles.nextPreview, { color: theme.textSecondary }]}
              >
                {nextStepPreview}
              </ThemedText>
            ) : null}
          </View>

          <View style={styles.navigationButtons}>
            {currentStepIndex > 0 ? (
              <Pressable
                onPress={handlePreviousStep}
                style={({ pressed }) => [
                  styles.navButton,
                  styles.prevButton,
                  { backgroundColor: theme.backgroundDefault, opacity: pressed ? 0.8 : 1 },
                ]}
              >
                <Feather name="chevron-left" size={20} color={theme.text} />
                <ThemedText type="body" style={{ fontWeight: "500" }}>
                  Back
                </ThemedText>
              </Pressable>
            ) : (
              <View style={styles.navButtonPlaceholder} />
            )}

            <Pressable
              onPress={handleNextStep}
              style={({ pressed }) => [
                styles.navButton,
                styles.nextButton,
                {
                  backgroundColor:
                    currentStep.direction === "arrived"
                      ? Colors.light.success
                      : theme.primary,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <ThemedText type="body" style={{ color: "#FFFFFF", fontWeight: "600" }}>
                {currentStep.direction === "arrived" ? "Finish" : "Next"}
              </ThemedText>
              <Feather name="chevron-right" size={20} color="#FFFFFF" />
            </Pressable>
          </View>
        </BlurView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  fallbackCamera: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  fallbackText: {
    marginTop: Spacing.xl,
    textAlign: "center",
  },
  arOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },
  arrowContainer: {
    width: 150,
    height: 150,
    justifyContent: "center",
    alignItems: "center",
  },
  glowCircle: {
    position: "absolute",
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: Colors.light.primary,
  },
  arrowBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  arrowShape: {
    alignItems: "center",
  },
  arrowHead: {
    width: 0,
    height: 0,
    borderLeftWidth: 35,
    borderRightWidth: 35,
    borderBottomWidth: 50,
    borderLeftColor: "transparent",
    borderRightColor: "transparent",
  },
  arrowStem: {
    width: 30,
    height: 40,
    marginTop: -5,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  topBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  closeButton: {
    borderRadius: 22,
    overflow: "hidden",
  },
  blurButton: {
    width: 44,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
  },
  destinationBadge: {
    flex: 1,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
    alignItems: "center",
  },
  stepIndicator: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
    overflow: "hidden",
  },
  bottomSection: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.md,
  },
  instructionCard: {
    borderRadius: BorderRadius.xl,
    overflow: "hidden",
    padding: Spacing.md,
  },
  progressBarContainer: {
    marginBottom: Spacing.md,
  },
  progressBarBg: {
    height: 4,
    borderRadius: 2,
    overflow: "hidden",
  },
  progressBarFill: {
    height: "100%",
    borderRadius: 2,
  },
  instructionContent: {
    marginBottom: Spacing.md,
  },
  instructionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  directionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  instructionTextContainer: {
    flex: 1,
  },
  distanceText: {
    marginTop: Spacing.xs,
  },
  nextPreview: {
    marginTop: Spacing.sm,
    paddingLeft: 48 + Spacing.md,
  },
  navigationButtons: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  navButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.md,
    gap: Spacing.xs,
  },
  navButtonPlaceholder: {
    flex: 1,
  },
  prevButton: {
    flex: 1,
  },
  nextButton: {
    flex: 2,
  },
});
