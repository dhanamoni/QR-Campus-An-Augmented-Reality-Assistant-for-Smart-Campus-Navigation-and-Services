import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Platform,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CameraView, useCameraPermissions, BarcodeScanningResult } from "expo-camera";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  withSpring,
} from "react-native-reanimated";
import { NativeStackScreenProps } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { ENTRANCES, EntranceType } from "@/constants/routes";

type Props = NativeStackScreenProps<RootStackParamList, "QRScanner">;

const SCAN_FRAME_SIZE = 240;

export default function QRScannerScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const { theme, isDark } = useTheme();
  const [permission, requestPermission] = useCameraPermissions();
  const [flashOn, setFlashOn] = useState(false);
  const [scanned, setScanned] = useState(false);

  const scanLinePosition = useSharedValue(0);
  const frameOpacity = useSharedValue(1);

  useEffect(() => {
    scanLinePosition.value = withRepeat(
      withSequence(
        withTiming(SCAN_FRAME_SIZE - 4, { duration: 2000 }),
        withTiming(0, { duration: 2000 })
      ),
      -1,
      false
    );

    frameOpacity.value = withRepeat(
      withSequence(
        withTiming(0.5, { duration: 1000 }),
        withTiming(1, { duration: 1000 })
      ),
      -1,
      true
    );
  }, []);

  const scanLineStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: scanLinePosition.value }],
  }));

  const frameStyle = useAnimatedStyle(() => ({
    opacity: frameOpacity.value,
  }));

  const handleBarCodeScanned = (result: BarcodeScanningResult) => {
    if (scanned) return;
    
    const { data } = result;
    let entrance: EntranceType | null = null;

    if (data.toLowerCase().includes("entrance1") || data === "1") {
      entrance = ENTRANCES.ENTRANCE1;
    } else if (data.toLowerCase().includes("entrance2") || data === "2") {
      entrance = ENTRANCES.ENTRANCE2;
    }

    if (entrance) {
      setScanned(true);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      navigation.navigate("Destination", { entrance });
    }
  };

  const handleManualEntrance = (entrance: EntranceType) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    navigation.navigate("Destination", { entrance });
  };

  const toggleFlash = () => {
    setFlashOn((prev) => !prev);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      setScanned(false);
    });
    return unsubscribe;
  }, [navigation]);

  if (!permission) {
    return (
      <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
        <ThemedText type="body">Loading camera...</ThemedText>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View
        style={[
          styles.container,
          styles.permissionContainer,
          { backgroundColor: theme.backgroundRoot, paddingTop: insets.top + Spacing.xl },
        ]}
      >
        <View style={styles.permissionContent}>
          <View
            style={[
              styles.iconCircle,
              { backgroundColor: Colors.light.primary + "20" },
            ]}
          >
            <Feather name="camera" size={48} color={theme.primary} />
          </View>
          <ThemedText type="h2" style={styles.permissionTitle}>
            Camera Access Required
          </ThemedText>
          <ThemedText
            type="body"
            style={[styles.permissionText, { color: theme.textSecondary }]}
          >
            Campus Navigator needs camera access to scan entrance QR codes and display AR navigation arrows.
          </ThemedText>

          {permission.status === "denied" && !permission.canAskAgain ? (
            Platform.OS !== "web" ? (
              <Pressable
                onPress={async () => {
                  try {
                    await Linking.openSettings();
                  } catch (error) {
                    // openSettings not supported
                  }
                }}
                style={({ pressed }) => [
                  styles.permissionButton,
                  { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
                ]}
              >
                <ThemedText type="body" style={{ color: "#FFFFFF", fontWeight: "600" }}>
                  Open Settings
                </ThemedText>
              </Pressable>
            ) : (
              <ThemedText type="body" style={{ color: theme.textSecondary, textAlign: "center" }}>
                Run in Expo Go to use this feature
              </ThemedText>
            )
          ) : (
            <Pressable
              onPress={requestPermission}
              style={({ pressed }) => [
                styles.permissionButton,
                { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <ThemedText type="body" style={{ color: "#FFFFFF", fontWeight: "600" }}>
                Enable Camera
              </ThemedText>
            </Pressable>
          )}
        </View>

        <View style={[styles.manualSection, { paddingBottom: insets.bottom + Spacing.xl }]}>
          <ThemedText
            type="small"
            style={[styles.manualLabel, { color: theme.textSecondary }]}
          >
            Or select entrance manually
          </ThemedText>
          <View style={styles.manualButtonsRow}>
            <Pressable
              onPress={() => handleManualEntrance(ENTRANCES.ENTRANCE1)}
              style={({ pressed }) => [
                styles.manualButton,
                { backgroundColor: theme.backgroundDefault, opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <ThemedText type="body" style={{ fontWeight: "500" }}>
                Entrance 1
              </ThemedText>
            </Pressable>
            <Pressable
              onPress={() => handleManualEntrance(ENTRANCES.ENTRANCE2)}
              style={({ pressed }) => [
                styles.manualButton,
                { backgroundColor: theme.backgroundDefault, opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <ThemedText type="body" style={{ fontWeight: "500" }}>
                Entrance 2
              </ThemedText>
            </Pressable>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView
        style={StyleSheet.absoluteFill}
        facing="back"
        enableTorch={flashOn}
        barcodeScannerSettings={{
          barcodeTypes: ["qr"],
        }}
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
      />

      <View style={StyleSheet.absoluteFill}>
        <View style={[styles.overlay, { paddingTop: insets.top }]}>
          <View style={styles.header}>
            <BlurView
              intensity={80}
              tint={isDark ? "dark" : "light"}
              style={styles.headerBlur}
            >
              <ThemedText type="h3" style={styles.headerTitle}>
                Campus Navigator
              </ThemedText>
            </BlurView>
            <Pressable
              onPress={toggleFlash}
              style={({ pressed }) => [
                styles.flashButton,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <BlurView
                intensity={80}
                tint={isDark ? "dark" : "light"}
                style={styles.flashBlur}
              >
                <Feather
                  name={flashOn ? "zap" : "zap-off"}
                  size={20}
                  color={flashOn ? Colors.light.warning : theme.text}
                />
              </BlurView>
            </Pressable>
          </View>
        </View>

        <View style={styles.scanArea}>
          <Animated.View style={[styles.scanFrame, frameStyle]}>
            <View style={[styles.corner, styles.cornerTL]} />
            <View style={[styles.corner, styles.cornerTR]} />
            <View style={[styles.corner, styles.cornerBL]} />
            <View style={[styles.corner, styles.cornerBR]} />
            <Animated.View style={[styles.scanLine, scanLineStyle]} />
          </Animated.View>
        </View>

        <View style={[styles.bottomSection, { paddingBottom: insets.bottom + Spacing.xl }]}>
          <BlurView
            intensity={80}
            tint={isDark ? "dark" : "light"}
            style={styles.instructionCard}
          >
            <Feather name="maximize" size={24} color={theme.primary} />
            <ThemedText type="body" style={styles.instructionText}>
              Scan entrance QR code to begin navigation
            </ThemedText>
          </BlurView>

          <View style={styles.manualSection}>
            <ThemedText
              type="small"
              style={[styles.manualLabel, { color: "rgba(255,255,255,0.7)" }]}
            >
              Or select entrance manually
            </ThemedText>
            <View style={styles.manualButtonsRow}>
              <Pressable
                onPress={() => handleManualEntrance(ENTRANCES.ENTRANCE1)}
                style={({ pressed }) => [
                  styles.manualButtonCamera,
                  { opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <BlurView intensity={60} tint="dark" style={styles.manualButtonBlur}>
                  <ThemedText
                    type="body"
                    style={{ color: "#FFFFFF", fontWeight: "500" }}
                  >
                    Entrance 1
                  </ThemedText>
                </BlurView>
              </Pressable>
              <Pressable
                onPress={() => handleManualEntrance(ENTRANCES.ENTRANCE2)}
                style={({ pressed }) => [
                  styles.manualButtonCamera,
                  { opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <BlurView intensity={60} tint="dark" style={styles.manualButtonBlur}>
                  <ThemedText
                    type="body"
                    style={{ color: "#FFFFFF", fontWeight: "500" }}
                  >
                    Entrance 2
                  </ThemedText>
                </BlurView>
              </Pressable>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  permissionContainer: {
    justifyContent: "space-between",
  },
  permissionContent: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
  },
  iconCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  permissionTitle: {
    textAlign: "center",
    marginBottom: Spacing.md,
  },
  permissionText: {
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  permissionButton: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderRadius: BorderRadius.full,
    minWidth: 180,
    alignItems: "center",
  },
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
  },
  header: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.md,
  },
  headerBlur: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
  },
  headerTitle: {
    textAlign: "center",
  },
  flashButton: {
    position: "absolute",
    right: Spacing.md,
  },
  flashBlur: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
  scanArea: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  scanFrame: {
    width: SCAN_FRAME_SIZE,
    height: SCAN_FRAME_SIZE,
    position: "relative",
  },
  corner: {
    position: "absolute",
    width: 30,
    height: 30,
    borderColor: "#FFFFFF",
  },
  cornerTL: {
    top: 0,
    left: 0,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderTopLeftRadius: 8,
  },
  cornerTR: {
    top: 0,
    right: 0,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderTopRightRadius: 8,
  },
  cornerBL: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderBottomLeftRadius: 8,
  },
  cornerBR: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderBottomRightRadius: 8,
  },
  scanLine: {
    position: "absolute",
    left: 4,
    right: 4,
    height: 2,
    backgroundColor: Colors.light.primary,
    top: 2,
  },
  bottomSection: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.lg,
  },
  instructionCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
    gap: Spacing.md,
  },
  instructionText: {
    flex: 1,
  },
  manualSection: {
    marginTop: Spacing.lg,
    alignItems: "center",
  },
  manualLabel: {
    marginBottom: Spacing.sm,
  },
  manualButtonsRow: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  manualButton: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  manualButtonCamera: {
    overflow: "hidden",
    borderRadius: BorderRadius.md,
  },
  manualButtonBlur: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
  },
});
