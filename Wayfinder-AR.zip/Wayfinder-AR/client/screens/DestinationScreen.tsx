import React from "react";
import { View, StyleSheet, ScrollView, Pressable, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  WithSpringConfig,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { DESTINATIONS, getRoute, Destination } from "@/constants/routes";
import { HeaderButton } from "@react-navigation/elements";

type Props = NativeStackScreenProps<RootStackParamList, "Destination">;

const springConfig: WithSpringConfig = {
  damping: 15,
  mass: 0.3,
  stiffness: 150,
  overshootClamping: true,
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

interface DestinationCardProps {
  destination: Destination;
  onPress: () => void;
}

function DestinationCard({ destination, onPress }: DestinationCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.96, springConfig);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, springConfig);
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.card,
        { backgroundColor: theme.backgroundDefault },
        animatedStyle,
      ]}
    >
      <View
        style={[
          styles.iconContainer,
          { backgroundColor: Colors.light.primary + "15" },
        ]}
      >
        <Feather
          name={destination.icon as any}
          size={28}
          color={theme.primary}
        />
      </View>
      <ThemedText type="h4" style={styles.cardTitle} numberOfLines={2}>
        {destination.name}
      </ThemedText>
      <ThemedText
        type="small"
        style={[styles.cardTime, { color: theme.textSecondary }]}
      >
        {destination.estimatedTime} walk
      </ThemedText>
    </AnimatedPressable>
  );
}

export default function DestinationScreen({ navigation, route }: Props) {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { entrance } = route.params;

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <HeaderButton
          onPress={() => navigation.navigate("Settings")}
          accessibilityLabel="Settings"
        >
          <Feather name="settings" size={22} color={theme.text} />
        </HeaderButton>
      ),
    });
  }, [navigation, theme]);

  const handleDestinationPress = (destination: Destination) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }

    const navigationRoute = getRoute(entrance, destination.id);
    if (navigationRoute) {
      navigation.navigate("ARNavigation", {
        entrance,
        destination,
        route: navigationRoute,
      });
    }
  };

  const entranceLabel = entrance === "Entrance1" ? "Entrance 1" : "Entrance 2";

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.entranceInfo}>
          <View
            style={[
              styles.entranceBadge,
              { backgroundColor: Colors.light.success + "20" },
            ]}
          >
            <Feather name="map-pin" size={16} color={Colors.light.success} />
            <ThemedText
              type="small"
              style={[styles.entranceText, { color: Colors.light.success }]}
            >
              Starting from {entranceLabel}
            </ThemedText>
          </View>
        </View>

        <ThemedText type="h2" style={styles.sectionTitle}>
          Where would you like to go?
        </ThemedText>

        <View style={styles.grid}>
          {DESTINATIONS.map((destination) => (
            <DestinationCard
              key={destination.id}
              destination={destination}
              onPress={() => handleDestinationPress(destination)}
            />
          ))}
        </View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
  },
  entranceInfo: {
    marginBottom: Spacing.lg,
  },
  entranceBadge: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
    gap: Spacing.xs,
  },
  entranceText: {
    fontWeight: "500",
  },
  sectionTitle: {
    marginBottom: Spacing.lg,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.md,
  },
  card: {
    width: "47%",
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    alignItems: "center",
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  cardTitle: {
    textAlign: "center",
    marginBottom: Spacing.xs,
  },
  cardTime: {
    textAlign: "center",
  },
});
