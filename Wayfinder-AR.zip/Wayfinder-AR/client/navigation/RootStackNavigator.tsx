import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import QRScannerScreen from "@/screens/QRScannerScreen";
import DestinationScreen from "@/screens/DestinationScreen";
import ARNavigationScreen from "@/screens/ARNavigationScreen";
import ArrivalScreen from "@/screens/ArrivalScreen";
import SettingsScreen from "@/screens/SettingsScreen";
import { EntranceType, Destination, Route } from "@/constants/routes";

export type RootStackParamList = {
  QRScanner: undefined;
  Destination: { entrance: EntranceType };
  ARNavigation: { entrance: EntranceType; destination: Destination; route: Route };
  Arrival: { destination: Destination };
  Settings: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootStackNavigator() {
  const screenOptions = useScreenOptions();
  const opaqueOptions = useScreenOptions({ transparent: false });

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="QRScanner"
        component={QRScannerScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Destination"
        component={DestinationScreen}
        options={{ 
          ...opaqueOptions,
          headerTitle: "Select Destination",
        }}
      />
      <Stack.Screen
        name="ARNavigation"
        component={ARNavigationScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Arrival"
        component={ArrivalScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          presentation: "modal",
          headerTitle: "Settings",
        }}
      />
    </Stack.Navigator>
  );
}
